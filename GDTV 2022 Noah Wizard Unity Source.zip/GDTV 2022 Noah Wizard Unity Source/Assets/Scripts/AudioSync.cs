using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioSync : MonoBehaviour
{
    //by KevinAnthony & rutter
      //set these in the inspector!
     public AudioSource master;
     public AudioSource[] followers;
    // Start is called before the first frame update
    void Start()
    {
        SyncSources();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private IEnumerator SyncSources()
     {
         while (true)
         {
             foreach (var follower in followers)
             {
                 follower.timeSamples = master.timeSamples;
                 yield return null;
             }
         }    
     } 
}
