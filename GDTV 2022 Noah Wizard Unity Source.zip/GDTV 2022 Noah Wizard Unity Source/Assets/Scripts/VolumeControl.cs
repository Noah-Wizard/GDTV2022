using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VolumeControl : MonoBehaviour
{
    public AudioSource audioData;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Pause()
    {
        audioData.Pause();
    }


     public void RaiseVolume()
 {
     audioData.volume = 1f;
     //answer by Casiell
     //StartCoroutine(ChangeVolumeCoroutine());
 }
 
 private IEnumerator ChangeVolumeCoroutine()
 {
     while (audioData.volume < 1f)
     {
         audioData.volume += 0.003f;
         yield return null;
     }
 }

 public void MuteVolume()
 {
     audioData.volume = 0f;
     //answer by Casiell
     //StartCoroutine(MuteVolumeCoroutine());
 }
 
 private IEnumerator MuteVolumeCoroutine()
 {
     while (audioData.volume > 0f)
     {
         audioData.volume -= 0.003f;
         yield return null;
     }
 }
}
