using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonHitArea : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //recklessly incomplete answer by PrefixWiz on YouTube
        //final solve from Onurcan Onder at stack overflow. have to switch mesh type to full rect
        this.GetComponent<Image>().alphaHitTestMinimumThreshold = 0.1f;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
